create procedure test(IN id int)
BEGIN
   CASE id
	 WHEN 1 THEN SELECT SignalValue FROM pack_503_100c_s;
	 WHEN 2 THEN SELECT CodeID FROM pack_503_100c_s;
	 END CASE;
END;

