package cn.nci.test;

/**
 * @program: centispacesg
 * @description:
 * @author: xiejianfeng
 * @create: 2020-09-28 17:26
 */
public class IntegerISNullTest {
    public static void main(String[] args) {
        Integer a = null;
        if (a == null) {
            System.out.println("111");
        } else {
            System.out.println("222");
        }
    }
}
